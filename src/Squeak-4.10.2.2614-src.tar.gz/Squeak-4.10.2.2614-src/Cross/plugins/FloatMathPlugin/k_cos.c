#include "ieee754names.h"
#include "fdlibm/k_cos.c"
