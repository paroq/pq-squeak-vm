int sqInternetConfigurationInit(void);
int sqInternetConfigurationGetStringKeyedBykeySizeinto(char * aKey, int keyLength, char *nameptr);
int sqInternetConfigurationShutdown(void);
#pragma export on
void sqInternetGetMacintoshFileTypeAndCreatorFromkeySizeinto(char * aFileName, int keyLength, char * creator);
#pragma export off
