#include "ieee754names.h"
#include "fdlibm/s_log1p.c"
