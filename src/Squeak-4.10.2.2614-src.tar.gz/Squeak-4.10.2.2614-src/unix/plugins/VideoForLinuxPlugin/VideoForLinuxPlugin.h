#ifndef _VIDEO_FOR_LINUX_PLUGIN_H
#define _VIDEO_FOR_LINUX_PLUGIN_H

#include "videolib.h"

#endif
