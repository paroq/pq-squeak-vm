int ioMapCodeCache(int size);
