/* a stub for triboxoverlap */
int triBoxOverlap(float *a, float *b, float *c, float *d, float *e) {
  return 0;
}
