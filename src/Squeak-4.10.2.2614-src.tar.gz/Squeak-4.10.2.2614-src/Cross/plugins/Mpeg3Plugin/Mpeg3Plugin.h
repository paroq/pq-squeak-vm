	#include "changesForSqueak.h"
	#include "libmpeg3.h"
